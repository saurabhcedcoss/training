<?php

namespace Ced\Cedslide\Model;
use Magento\Framework\Model\AbstractModel;

class Slidedata extends AbstractModel
{

    const CACHE_TAG = 'slider_id';

    protected function _construct()

    {

        $this->_init('Ced\Cedslide\Model\ResourceModel\Slidedata');
    }

    public function getIdentities()

    {

        return [self::CACHE_TAG . '_' . $this->getslider_Id()];
    }
}
