<?php
namespace Ced\Cedslide\Model\ResourceModel\Slidedata;

// use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
// use Ced\Cedslide\Model\Slidedata as Model;
// use Ced\Cedslide\Model\ResourceModel\Slidedata as ResourceModel;

// class Collection extends AbstractCollection
// {
//     protected function _construct()
//     {
//         $this->_init(Model::class, ResourceModel::class);
//     }
// }
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection

{

protected function _construct()

{

$this->_init('Ced\Cedslide\Model\Slidedata','Ced\Cedslide\Model\ResourceModel\Slidedata');

}

}