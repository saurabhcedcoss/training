<?php

namespace Ced\Cedslide\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Slidedata extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('cedslider_table', 'slider_id');
    }
}
