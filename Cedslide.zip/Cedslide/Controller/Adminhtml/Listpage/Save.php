<?php
namespace Ced\Cedslide\Controller\Adminhtml\Listpage;

class Save extends \Magento\Backend\App\Action
 
{
 
    protected $customFactory;
 
    protected $adapterFactory;
 
    protected $uploader;
 
    public function __construct(
 
        \Magento\Backend\App\Action\Context $context,
 
        \Ced\Cedslide\Model\SlidedataFactory $customFactory
 
    ) {
 
        parent::__construct($context);
 
        $this->customFactory = $customFactory;
 
    }
 
    public function execute()
 
    {
 
        $data = $this->getRequest()->getPostValue();
 
        try {
 
            $model = $this->customFactory->create();
 
$model->addData([
 
    "slider_image" => $data['slider_image'],
 
    "slider_image_name" => $data['slider_image_name'],
 
    "slider_description" => $data['slider_description'],
 
]);
 
$saveData = $model->save();
 
if($saveData){
 
    $this->messageManager->addSuccess( __('Insert data Successfully !') );
 
}
 
        }catch (\Exception $e) {
 
            $this->messageManager->addError(__($e->getMessage()));
 
        }
 
        $this->_redirect('*/*/index');
 
    }
 
}
