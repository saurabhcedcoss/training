<?php

use Symfony\Component\VarDumper\Caster\DsCaster;
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Ced_CatalogList',
	__DIR__
);