<?php

namespace Ced\Datauser\Model;

use Magento\Framework\Model\AbstractModel;
use Ced\Datauser\Model\ResourceModel\Data as ResourceModel;

class Data extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}