<?php
namespace Ced\Datauser\Model\ResourceModel\Data;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Ced\Datauser\Model\Data as Model;
use Ced\Datauser\Model\ResourceModel\Data as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
