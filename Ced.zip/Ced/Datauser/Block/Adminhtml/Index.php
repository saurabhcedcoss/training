<?php

namespace Ced\Datauser\Block\Adminhtml;

use Magento\Backend\Block\Template;

class Index extends Template
{
    private $collection;

    public function __construct(
        Template\Context $context,
        \Ced\Datauser\Model\ResourceModel\Data\Collection $collection,
        array $data = []
    ) {
        $this->collection = $collection;
        parent::__construct($context, $data);
    }

    
    public function getAllUsers()
    {
        $usdata = $this->collection;
        echo '<table border="1">
        <tr><th>ID</th><th>Name</th><th>Contact</th></tr>';
        foreach ($usdata as $usdata) {
            echo '<tr>
            <td>' . $usdata->getId() . '</td>
            <td>' . $usdata->getTitle() . '</td>
            <td>' . $usdata->getContact() . '</td>
            </tr>';
        }
    }
}
