<?php
namespace Ced\Slider\Adminhtml\Listslide;

// use \Magento\Backend\App\Action\Context as Context;
// use \Magento\Framework\View\Result\PageFactory as PageFactory;
// use \Magento\Backend\App\Action as Action;

// class Index extends Action
// {
//   protected $resultPageFactory = false;

//   public function __construct(
//     Context $context,
//     PageFactory $resultPageFactory
//   ) {
//     parent::__construct($context);
//     $this->resultPageFactory = $resultPageFactory;
//   }

//   public function execute()
//   {
//     $resultPage = $this->resultPageFactory->create();
//     $resultPage->setActiveMenu('Ced_Slider::sliderform');
//     $resultPage->getConfig()->getTitle()->prepend((__('Sliders')));
//     return $resultPage;
//   }
//namespace Mageplaza\HelloWorld\Controller\Index;

class Test extends \Magento\Backend\App\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		echo "Hello World";
		exit;
	}
}


//}