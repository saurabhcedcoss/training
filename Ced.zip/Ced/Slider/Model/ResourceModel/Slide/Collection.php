<?php
namespace Ced\Slider\Model\ResourceModel\Data;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Ced\Slider\Model\Slide as Model;
use Ced\Slider\Model\ResourceModel\Slide as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
