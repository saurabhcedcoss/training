<?php

namespace Ced\Slider\Model;

use Magento\Framework\Model\AbstractModel;
use Ced\Slider\Model\ResourceModel\Slide as ResourceModel;

class Slide extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}