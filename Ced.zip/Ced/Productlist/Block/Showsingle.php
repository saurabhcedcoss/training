<?php
namespace Ced\Productlist\Block;

class Showsingle extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        array $data = []
    ) {
        $this->productRepository = $productRepository;
        parent::__construct($context, $data);
    }

    public function getProductBySku($sku)
    {
        return $this->productRepository->get($sku);
    }
}
