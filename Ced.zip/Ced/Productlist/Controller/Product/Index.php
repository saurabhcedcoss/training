<?php
namespace Ced\Productlist\Controller\Product;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		$allProd = $this->_pageFactory->create();
		$allProd->addHandle('productlist_product_index');
		return $allProd;
	}
}